﻿using System;
using System.ComponentModel;

namespace QuestechSystems.SharePoint.ComponentModel
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public class SPCategoryAttribute : CategoryAttribute
    {
        private readonly string _classKey;

        public SPCategoryAttribute(string classKey, string resourceKey)
            : base(resourceKey)
        {
            _classKey = classKey;
        }

        protected override string GetLocalizedString(string resourceKey)
        {
            var value = Utilities.Common.GetResourceString(_classKey, resourceKey);
            return String.IsNullOrEmpty(value) ? base.GetLocalizedString(resourceKey) : value;
        }
    }
}