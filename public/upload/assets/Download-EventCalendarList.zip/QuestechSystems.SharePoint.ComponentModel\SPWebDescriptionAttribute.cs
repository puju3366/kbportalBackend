﻿using System;
using System.ComponentModel;

namespace QuestechSystems.SharePoint.ComponentModel
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public class SPWebDescriptionAttribute : DescriptionAttribute
    {
        private readonly string _classKey;
        private readonly string _resourceKey;

        public SPWebDescriptionAttribute(string classKey, string resourceKey)
        {
            _classKey = classKey;
            _resourceKey = resourceKey;
        }

        public override string Description
        {
            get
            {
                var value = Utilities.Common.GetResourceString(_classKey, _resourceKey);
                if (String.IsNullOrEmpty(value))
                {
                    value = _resourceKey;
                }
                return DescriptionValue = value;
            }
        }
    }
}