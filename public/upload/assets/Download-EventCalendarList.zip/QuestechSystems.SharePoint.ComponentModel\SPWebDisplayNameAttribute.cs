﻿using System;
using System.Web.UI.WebControls.WebParts;

namespace QuestechSystems.SharePoint.ComponentModel
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public class SPWebDisplayNameAttribute : WebDisplayNameAttribute
    {
        private readonly string _classKey;
        private readonly string _resourceKey;

        public SPWebDisplayNameAttribute(string classKey, string resourceKey)
        {
            _classKey = classKey;
            _resourceKey = resourceKey;
        }

        public override string DisplayName
        {
            get
            {
                var value = Utilities.Common.GetResourceString(_classKey, _resourceKey);
                if (String.IsNullOrEmpty(value))
                {
                    value = _resourceKey;
                }
                return DisplayNameValue = value;
            }
        }
    }
}