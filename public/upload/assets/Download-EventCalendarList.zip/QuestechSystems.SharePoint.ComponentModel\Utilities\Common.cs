﻿using System;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace QuestechSystems.SharePoint.ComponentModel.Utilities
{
    internal class Common
    {
        internal static string GetResourceString(string classKey, string resourceKey)
        {
            try
            {
                return SPUtility.GetLocalizedString(
                    String.Format("$Resources:{0}", resourceKey),
                    classKey,
                    SPContext.Current.Web.Language);
            }
            catch
            {
                return resourceKey;
            }
        }
    }
}