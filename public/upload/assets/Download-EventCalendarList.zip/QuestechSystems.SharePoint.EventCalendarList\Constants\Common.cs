﻿//
//	Common.cs - © Questech Systems
//	This notice must stay intact for use. Not for resale.
//
namespace QuestechSystems.SharePoint.EventCalendarList.Constants
{
    internal static class Common
    {
        internal const int NumDaysToLookAheadForEvents = 90;

        internal const string AjaxScriptBlock = @"
                    with (Sys.WebForms.PageRequestManager.getInstance()) {
                        add_endRequest(onEndRequest);
                    }
                    function onEndRequest(sender, args) {                          
                        dw_Event.add( window, 'load', dw_Tooltip.init );
                    }";
        internal const string EventCalendarCamlQuery =
            @"<Where><DateRangesOverlap><FieldRef Name=""EventDate"" /><FieldRef Name=""EndDate"" /><FieldRef Name=""RecurrenceID"" /><Value Type=""DateTime""><Month /></Value></DateRangesOverlap></Where>";
        internal const string EventListingCamlQuery =
            @"<Where><DateRangesOverlap><FieldRef Name=""EventDate"" /><FieldRef Name=""EndDate"" /><FieldRef Name=""RecurrenceID"" /><Value Type=""DateTime""><Now /></Value></DateRangesOverlap></Where><OrderBy><FieldRef Name=""EventDate"" /></OrderBy>";

        internal const string LayoutPath = "/_layouts/15/QuestechSystems.SharePoint.EventCalendarList";

        internal const string RegisterCsKeyAjaxScript = "CsKeyAjaxScript";
    }
}