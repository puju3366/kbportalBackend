﻿//
//	Styles.cs - © Questech Systems
//	This notice must stay intact for use. Not for resale.
//
namespace QuestechSystems.SharePoint.EventCalendarList.Constants
{
    internal static class Styles
    {
        internal const string AllDayEventDurationFormatString = "{0} - {1}";
        internal const string DefaultCssClassEventListing = "ecl-listing";
        internal const string DefaultCssClassCalendar = "ecl-calendar";
        internal const string DefaultCssClassDay = "ecl-day";
        internal const string DefaultCssClassEvent = "ecl-event";
        internal const string DefaultCssClassToday = "ecl-today";
        internal const string DefaultCssClassWeekend = "ecl-weekend";
        internal const string DefaultCssClassOtherMonth = "ecl-other-month";
        internal const string EventDurationTooltipFormatString = "{0} {1} - {2} {3}";
        internal const string EventListingDurationHtmlFormatString = " ({0})";
        internal const string EventListingHeadingHtmlFormatString = "<h3>{0}</h3>";
    }
}