﻿dw_Tooltip.defaultProps = {
    content_source: 'class_id', // class holds id of element with tooltip content
    hoverable: true,    // tooltip lingers so user can hover to click links
    supportTouch: true,  // enables support for touch devices
    offX: 2,
    offY: 8
}

dw_Tooltip.writeStyleRule();