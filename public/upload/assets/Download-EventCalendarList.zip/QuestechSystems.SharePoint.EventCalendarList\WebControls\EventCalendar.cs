//
//	EventCalendar.cs - � Questech Systems
//	This notice must stay intact for use. Not for resale.
//
using System;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;

namespace QuestechSystems.SharePoint.EventCalendarList.WebControls
{
    public class EventCalendar : Calendar, INamingContainer
    {
        public string SiteUrl { get; set; }

        public string ListTitle { get; set; }

        public string ViewTitle { get; set; }

        public string CalendarDateString { get; set; }

        public string SiteRelativeEventItemUrl { get; set; }

        private SPList _eventsList;
        private SPListItemCollection _eventItems;
        private SPWeb _site;

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (String.IsNullOrWhiteSpace(ListTitle))
            {
                return;
            }

            _site = String.IsNullOrWhiteSpace(SiteUrl) ? SPContext.Current.Web : SPContext.Current.Site.OpenWeb(SiteUrl.Trim());
            if (_site == null)
            {
                return;
            }

            foreach (SPList list in _site.Lists)
            {
                if (list.Title.Equals(ListTitle, StringComparison.InvariantCultureIgnoreCase))
                {
                    _eventsList = list;
                    break;
                }
            }

            if (_eventsList == null)
            {
                return;
            }

            DateTime calendarDate;

            if (!DateTime.TryParse(CalendarDateString, out calendarDate))
            {
                calendarDate = DateTime.Now;
            }

            _eventItems = GetEventItems(calendarDate);
        }

        protected override void OnUnload(EventArgs e)
        {
            base.OnUnload(e);

            if (!String.IsNullOrEmpty(SiteUrl) && _site != null)
            {
                _site.Close();
            }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            var css = new CssRegistration
            {
                Name = Constants.Common.LayoutPath + "/STYLES/EventCalendar.css",
                After = "Themable/corev15.css"
            };
            base.Controls.Add(css);

            var scriptLink = new ScriptLink
            {
                Name = Constants.Common.LayoutPath + "/dw_tooltip_c.js",
                Language = "javascript",
                Localizable = false
            };
            base.Controls.Add(scriptLink);

            var scriptLink2 = new ScriptLink
            {
                Name = Constants.Common.LayoutPath + "/EventCalendar.js",
                Language = "javascript",
                Localizable = false
            };
            base.Controls.Add(scriptLink2);
        }

        protected override ControlCollection CreateControlCollection()
        {
            return new ControlCollection(this);
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (_eventsList == null)
            {
                return;
            }

            RegisterAjaxScript();

            //  Hide the default tooltip
            Attributes.Add("title", string.Empty);
            base.Render(writer);
        }

        protected override void OnVisibleMonthChanged(DateTime newDate, DateTime previousDate)
        {
            base.OnVisibleMonthChanged(newDate, previousDate);
            _eventItems = GetEventItems(newDate);
        }

        protected override void OnDayRender(TableCell cell, CalendarDay day)
        {
            cell.Controls.Clear();

            if (_eventsList == null || _eventItems.Count == 0)
            {
                cell.Controls.Add(new LiteralControl(day.DayNumberText));
            }
            else
            {
                if (CreateCellControls(cell, day))
                {
                    cell.CssClass += " " + SelectedDayStyle.CssClass;
                }
            }

            base.OnDayRender(cell, day);
        }

        private void RegisterAjaxScript()
        {
            var scriptManager = ScriptManager.GetCurrent(Page);
            if (scriptManager != null && scriptManager.IsInAsyncPostBack)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), Constants.Common.RegisterCsKeyAjaxScript,
                    Constants.Common.AjaxScriptBlock, true);
            }
            else
            {
                var cs = Page.ClientScript;
                if (!cs.IsClientScriptBlockRegistered(GetType(), Constants.Common.RegisterCsKeyAjaxScript))
                {
                    cs.RegisterClientScriptBlock(GetType(), Constants.Common.RegisterCsKeyAjaxScript,
                        Constants.Common.AjaxScriptBlock, true);
                }
            }
        }

        private SPListItemCollection GetEventItems(DateTime calendarDate)
        {
            var query = new SPQuery
            {
                ExpandRecurrence = true,
                CalendarDate = calendarDate,
                Query = Constants.Common.EventCalendarCamlQuery
            };

            if (!String.IsNullOrWhiteSpace(ViewTitle))
            {
                foreach (SPView view in _eventsList.Views)
                {
                    if (String.Compare(view.Title, ViewTitle, StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        query.Query = view.Query;
                        break;
                    }
                }
            }

            return _eventsList.GetItems(query);
        }

        private bool CreateCellControls(TableCell cell, CalendarDay day)
        {
            var dayHasEvent = false;
            Panel eventPopUpPanel = null;

            foreach (SPListItem item in _eventItems)
            {
                var eventStartDate = Convert.ToDateTime(item["EventDate"]);
                var eventEndDate = Convert.ToDateTime(item["EndDate"]);
                if (DateTime.Compare(eventStartDate.Date, day.Date.Date) > 0 ||
                    DateTime.Compare(day.Date.Date, eventEndDate.Date) > 0)
                {
                    continue;
                }
                var itemId = int.Parse(item["ID"].ToString());
                if (!dayHasEvent)
                {
                    dayHasEvent = true;
                    eventPopUpPanel = new Panel
                    {
                        ID = String.Format("{0}{1}", UniqueID, day.Date.ToString("yyyyMMdd")),
                        CssClass = "tipContent"
                    };
                    var titleLabel = new Label { Text = day.Date.ToLongDateString() };
                    eventPopUpPanel.Controls.Add(titleLabel);
                    eventPopUpPanel.Controls.Add(new LiteralControl("<ul>"));
                }
                eventPopUpPanel.Controls.Add(new LiteralControl("<li>"));
                var eventHyperLink = new HyperLink
                {
                    Text = SPEncode.HtmlEncode(item["Title"].ToString()),
                    NavigateUrl = GetItemUrl(itemId)
                };
                bool allDayEvent = item["fAllDayEvent"] != null && Convert.ToBoolean(item["fAllDayEvent"].ToString());
                eventHyperLink.ToolTip = GetEventDuration(eventStartDate, eventEndDate, allDayEvent);
                eventPopUpPanel.Controls.Add(eventHyperLink);
                eventPopUpPanel.Controls.Add(new LiteralControl("</li>"));
            }

            if (dayHasEvent)
            {
                eventPopUpPanel.Controls.Add(new LiteralControl("</ul>"));
                var dayHyperLink = new HyperLink
                {
                    Text = day.DayNumberText,
                    NavigateUrl = "javascript:void(null);",
                    CssClass = String.Format("showTip {0}", eventPopUpPanel.ClientID)
                };
                var eventPanel = new Panel();
                eventPanel.Controls.Add(dayHyperLink);
                eventPanel.Controls.Add(eventPopUpPanel);
                cell.Controls.Add(eventPanel);
            }
            else
            {
                cell.Controls.Add(new LiteralControl(day.DayNumberText));
            }

            return dayHasEvent;
        }

        private string GetItemUrl(int itemId)
        {
            string siteRelativeEventUrl = String.IsNullOrEmpty(SiteRelativeEventItemUrl) ? _eventsList.Forms[PAGETYPE.PAGE_DISPLAYFORM].Url : SiteRelativeEventItemUrl.TrimStart("/".ToCharArray());

            return String.Format("{0}/{1}?ID={2}&Source={3}", _eventsList.ParentWebUrl.TrimEnd("/".ToCharArray()),
                siteRelativeEventUrl, itemId, HttpUtility.UrlEncode(Page.Request.Url.PathAndQuery));
        }

        private string GetEventDuration(DateTime startDateTime, DateTime endDateTime, bool allDayEvent)
        {
            if (DateTime.Compare(startDateTime.Date, endDateTime.Date) == 0)
            {
                if (allDayEvent)
                {
                    return SPUtility.GetLocalizedString("$Resources:EventCalendarAllDayEvent",
                        Assembly.GetExecutingAssembly().GetName().Name, SPContext.Current.Web.Language);
                }
                return String.Format(Constants.Styles.AllDayEventDurationFormatString,
                    startDateTime.ToShortTimeString(),
                    endDateTime.ToShortTimeString());
            }

            if (allDayEvent)
            {
                return String.Format(Constants.Styles.AllDayEventDurationFormatString, startDateTime.ToShortDateString(),
                    endDateTime.ToShortDateString());
            }

            return String.Format(Constants.Styles.EventDurationTooltipFormatString, startDateTime.ToShortDateString(),
                startDateTime.ToShortTimeString(), endDateTime.ToShortDateString(), endDateTime.ToShortTimeString());
        }
    }
}