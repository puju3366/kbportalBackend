//
//	EventListing.cs - � Questech Systems
//	This notice must stay intact for use. Not for resale.
//
using System;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace QuestechSystems.SharePoint.EventCalendarList.WebControls
{
    public class EventListing : SPControl
    {
        public string SiteUrl { get; set; }

        public string ListTitle { get; set; }

        public string ViewTitle { get; set; }

        public int NumDaysInEventListing
        {
            get
            {
                return _numDaysInEventListing;
            }
            set
            {
                _numDaysInEventListing = value;
            }
        }

        public string SiteRelativeEventItemUrl { get; set; }

        public string CssClassEventListing { get; set; }

        private SPList _eventsList;
        private SPWeb _site;
        private int _numDaysInEventListing = 3;

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (String.IsNullOrWhiteSpace(ListTitle))
            {
                return;
            }

            _site = String.IsNullOrWhiteSpace(SiteUrl) ? SPContext.Current.Web : SPContext.Current.Site.OpenWeb(SiteUrl.Trim());
            if (_site == null)
            {
                return;
            }

            foreach (SPList list in _site.Lists)
            {
                if (list.Title.Equals(ListTitle, StringComparison.InvariantCultureIgnoreCase))
                {
                    _eventsList = list;
                    break;
                }
            }
        }

        protected override void OnUnload(EventArgs e)
        {
            base.OnUnload(e);

            if (!String.IsNullOrEmpty(SiteUrl) && _site != null)
            {
                _site.Close();
            }
        }

        protected override void CreateChildControls()
        {
            if (_eventsList == null)
            {
                return;
            }

            var css = new CssRegistration
            {
                Name = Constants.Common.LayoutPath + "/STYLES/EventListing.css",
                After = "Themable/corev15.css"
            };
            Controls.Add(css);

            var eventListingPanel = new Panel { CssClass = CssClassEventListing };
            PopulateEventListingPanel(eventListingPanel);
            Controls.Add(eventListingPanel);
        }

        private void PopulateEventListingPanel(Panel eventListingPanel)
        {
            var eventItems = GetEventItems(DateTime.Now);

            if (eventItems.Count == 0)
            {
                var messageLabel = new Label
                {
                    Text = SPUtility.GetLocalizedString("$Resources:MsgNoEvents",
                        Assembly.GetExecutingAssembly().GetName().Name, SPContext.Current.Web.Language)
                };
                eventListingPanel.Controls.Add(messageLabel);
                return;
            }

            var numDaysHaveEvent = 0;
            var day = DateTime.Now.Date;
            var dayWithEvents = day.AddDays(-1);
            var lastDay = day.AddDays(Constants.Common.NumDaysToLookAheadForEvents);

            while (DateTime.Compare(day, lastDay) < 0)
            {
                var dayHasEvent = false;
                foreach (SPListItem item in eventItems)
                {
                    var eventStartDate = Convert.ToDateTime(item["EventDate"]);
                    var eventEndDate = Convert.ToDateTime(item["EndDate"]);
                    if (DateTime.Compare(eventStartDate.Date, day) > 0 || DateTime.Compare(day, eventEndDate.Date) > 0)
                    {
                        continue;
                    }
                    if (DateTime.Compare(dayWithEvents, day) != 0)
                    {
                        eventListingPanel.Controls.Add(
                            new LiteralControl(String.Format(Constants.Styles.EventListingHeadingHtmlFormatString,
                                day.ToLongDateString())));
                        eventListingPanel.Controls.Add(new LiteralControl("<ul>"));
                        dayWithEvents = day;
                        dayHasEvent = true;
                        numDaysHaveEvent++;
                    }
                    var itemId = int.Parse(item["ID"].ToString());
                    eventListingPanel.Controls.Add(new LiteralControl("<li>"));
                    bool allDayEvent = item["fAllDayEvent"] != null && Convert.ToBoolean(item["fAllDayEvent"].ToString());
                    var eventHyperLink = new HyperLink
                    {
                        Text = SPEncode.HtmlEncode(item["Title"].ToString()),
                        NavigateUrl = GetItemUrl(itemId)
                    };
                    eventListingPanel.Controls.Add(eventHyperLink);
                    eventListingPanel.Controls.Add(
                        new LiteralControl(String.Format(Constants.Styles.EventListingDurationHtmlFormatString,
                            GetEventDuration(eventStartDate, eventEndDate, allDayEvent))));
                    eventListingPanel.Controls.Add(new LiteralControl("</li>"));
                }
                if (dayHasEvent)
                {
                    eventListingPanel.Controls.Add(new LiteralControl("</ul>"));
                }
                if (numDaysHaveEvent >= _numDaysInEventListing)
                {
                    break;
                }
                day = day.AddDays(1);
            }
        }

        private SPListItemCollection GetEventItems(DateTime calendarDate)
        {
            var query = new SPQuery
            {
                ExpandRecurrence = true,
                CalendarDate = calendarDate,
                Query = Constants.Common.EventListingCamlQuery
            };

            if (!String.IsNullOrWhiteSpace(ViewTitle))
            {
                foreach (SPView view in _eventsList.Views)
                {
                    if (String.Compare(view.Title, ViewTitle, StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        query.Query = view.Query;
                        break;
                    }
                }
            }

            return _eventsList.GetItems(query);
        }

        private string GetItemUrl(int itemId)
        {
            string siteRelativeEventUrl = String.IsNullOrEmpty(SiteRelativeEventItemUrl) ? _eventsList.Forms[PAGETYPE.PAGE_DISPLAYFORM].Url : SiteRelativeEventItemUrl.TrimStart("/".ToCharArray());

            return String.Format("{0}/{1}?ID={2}&Source={3}", _eventsList.ParentWebUrl.TrimEnd("/".ToCharArray()),
                siteRelativeEventUrl, itemId, HttpUtility.UrlEncode(Page.Request.Url.PathAndQuery));
        }

        private string GetEventDuration(DateTime startDateTime, DateTime endDateTime, bool allDayEvent)
        {
            if (DateTime.Compare(startDateTime.Date, endDateTime.Date) == 0)
            {
                if (allDayEvent)
                {
                    return SPUtility.GetLocalizedString("$Resources:EventCalendarAllDayEvent",
                        Assembly.GetExecutingAssembly().GetName().Name, SPContext.Current.Web.Language);
                }
                return String.Format(Constants.Styles.AllDayEventDurationFormatString,
                    startDateTime.ToShortTimeString(),
                    endDateTime.ToShortTimeString());
            }

            if (allDayEvent)
            {
                return String.Format(Constants.Styles.AllDayEventDurationFormatString, startDateTime.ToShortDateString(),
                    endDateTime.ToShortDateString());
            }

            return String.Format(Constants.Styles.EventDurationTooltipFormatString, startDateTime.ToShortDateString(),
                startDateTime.ToShortTimeString(), endDateTime.ToShortDateString(), endDateTime.ToShortTimeString());
        }
    }
}