﻿//
//	EventCalendarListWebPart.cs - © Questech Systems
//	This notice must stay intact for use. Not for resale.
//
using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using QuestechSystems.SharePoint.ComponentModel;
using QuestechSystems.SharePoint.EventCalendarList.WebControls;

namespace QuestechSystems.SharePoint.EventCalendarList.WebParts.EventCalendarListWebPart
{
    [ToolboxItemAttribute(false)]
    public class EventCalendarListWebPart : WebPart
    {
        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_SiteUrl")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_SiteUrl")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string SiteUrl { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_ListTitle")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_ListTitle")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string ListTitle { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_SiteRelativeEventItemUrl")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_SiteRelativeEventItemUrl")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string SiteRelativeEventItemUrl { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_EnableAsyncUpdate")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_EnableAsyncUpdate")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public bool EnableAsyncUpdate { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_ShowCalendar")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_ShowCalendar")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public bool ShowCalendar
        {
            get
            {
                return _showCalendar;
            }
            set
            {
                _showCalendar = value;
            }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CalendarViewTitle")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CalendarViewTitle")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CalendarViewTitle { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_FirstDayOfWeek")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_FirstDayOfWeek")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public FirstDayOfWeek FirstDayOfWeek
        {
            get
            {
                return _firstDayOfWeek;
            }
            set
            {
                _firstDayOfWeek = value;
            }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassCalendar")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassCalendar")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassCalendar { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassTitle")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassTitle")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassTitle { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassHeader")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassHeader")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassHeader { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassNextPrev")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassNextPrev")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassNextPrev { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassDay")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassDay")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassDay { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassEvent")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassEvent")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassEvent { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassToday")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassToday")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassToday { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassWeekend")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassWeekend")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassWeekend { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassOtherMonth")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassOtherMonth")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassOtherMonth { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_ShowListing")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_ShowListing")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public bool ShowListing
        {
            get
            {
                return _showListing;
            }
            set
            {
                _showListing = value;
            }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_ListingViewTitle")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_ListingViewTitle")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string ListingViewTitle { get; set; }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_NumDaysInEventListing")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_NumDaysInEventListing")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public int NumDaysInEventListing
        {
            get
            {
                return _numDaysInEventListing;
            }
            set
            {
                _numDaysInEventListing = value;
            }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [SPWebDisplayName("QuestechSystems.SharePoint.EventCalendarList", "WPDisplayName_CssClassEventListing")]
        [SPWebDescription("QuestechSystems.SharePoint.EventCalendarList", "WPDescription_CssClassEventListing")]
        [SPCategory("QuestechSystems.SharePoint.EventCalendarList", "SPCategory_Configuration")]
        public string CssClassEventListing { get; set; }

        private FirstDayOfWeek _firstDayOfWeek = FirstDayOfWeek.Default;
        private bool _showCalendar = true;
        private bool _showListing = true;
        private int _numDaysInEventListing = 3;

        protected override void CreateChildControls()
        {
            try
            {
                if (_showCalendar)
                {
                    if (EnableAsyncUpdate)
                    {
                        var updatePanel = new UpdatePanel
                        {
                            ID = "EventCalendarListPanel",
                            UpdateMode = UpdatePanelUpdateMode.Conditional
                        };
                        var eventCalendar = new EventCalendar { ID = "EventCalendar" };
                        InitEventCalendar(eventCalendar);
                        updatePanel.ContentTemplateContainer.Controls.Add(eventCalendar);
                        Controls.Add(updatePanel);
                    }
                    else
                    {
                        var eventCalendar = new EventCalendar { ID = "EventCalendar" };
                        InitEventCalendar(eventCalendar);
                        Controls.Add(eventCalendar);
                    }
                }

                if (_showListing)
                {
                    var eventListing = new EventListing();
                    InitEventListing(eventListing);
                    Controls.Add(eventListing);
                }
            }
            catch (Exception ex)
            {
                Controls.Add(new LiteralControl(ex.Message));
            }
        }

        private void InitEventCalendar(EventCalendar eventCalendar)
        {
            eventCalendar.SiteUrl = SiteUrl;
            eventCalendar.ListTitle = ListTitle;
            eventCalendar.ViewTitle = CalendarViewTitle;
            eventCalendar.FirstDayOfWeek = _firstDayOfWeek;
            eventCalendar.SiteRelativeEventItemUrl = SiteRelativeEventItemUrl;
            eventCalendar.CssClass = CssClassCalendar;
            //  If TitleStyle.CssClass is empty, for some reasons SharePoint sets it to CssClass.
            eventCalendar.TitleStyle.CssClass = String.IsNullOrWhiteSpace(CssClassTitle) ? " " : CssClassTitle;
            eventCalendar.DayHeaderStyle.CssClass = CssClassHeader;
            eventCalendar.NextPrevStyle.CssClass = CssClassNextPrev;
            eventCalendar.DayStyle.CssClass = CssClassDay;
            eventCalendar.SelectedDayStyle.CssClass = CssClassEvent;
            eventCalendar.TodayDayStyle.CssClass = CssClassToday;
            eventCalendar.WeekendDayStyle.CssClass = CssClassWeekend;
            eventCalendar.OtherMonthDayStyle.CssClass = CssClassOtherMonth;
        }

        private void InitEventListing(EventListing eventListing)
        {
            eventListing.CssClassEventListing = CssClassEventListing;
            eventListing.SiteUrl = SiteUrl;
            eventListing.ListTitle = ListTitle;
            eventListing.ViewTitle = ListingViewTitle;
            eventListing.NumDaysInEventListing = _numDaysInEventListing;
            eventListing.SiteRelativeEventItemUrl = SiteRelativeEventItemUrl;
        }
    }
}