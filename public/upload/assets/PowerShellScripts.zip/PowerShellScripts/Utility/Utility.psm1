<#
.DESCRIPTION
	This script contains shared functions used by the other PowerShell scripts in this Visual Studio solution.
#>


<#
	================================================================================================
	================================================================================================
	Exported functions
	================================================================================================
	================================================================================================
#>

function Utility_AssertValid_Directory
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string]$directory
	)

	if( !( Test-Path -Path $directory ) ) {
		throw "cannot find directory: $directory"
	}
}

function Utility_AssertValid_FilePath
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string]$filePath
	)

	if( !( Test-Path -Path $filePath ) ) {
		throw "cannot find file: $filePath"
	}
}

function Utility_BackupDirectory
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $sourceFilePathPattern,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $destinationDirectory
	)

	$sourceDirectory = Split-Path -Path $sourceFilePathPattern -Parent
	Utility_AssertValid_Directory $sourceDirectory

	if( !( Test-Path -Path $destinationDirectory ) ) {
		New-Item $destinationDirectory -ItemType directory 
		Utility_AssertValid_Directory $destinationDirectory
	}

	Utility_CopyFiles $sourceFilePathPattern $destinationDirectory
}

function Utility_BackupProjectOutputDirectory
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $inputDirectory
	)

	Utility_AssertValid_Directory $inputDirectory

	$sourceFilePathPattern = Join-Path -Path $inputDirectory -ChildPath "*.*"
	$destinationDirectory = Join-Path -Path $inputDirectory -ChildPath "NonObfuscatedAssemblyBackup"

	Utility_BackupDirectory $sourceFilePathPattern $destinationDirectory
}

function Utility_CopyFiles
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $sourceFilePathPattern,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $destinationDirectory
	)

	$sourceDirectory = Split-Path -Path $sourceFilePathPattern -Parent
	Utility_AssertValid_Directory $sourceDirectory
	Utility_AssertValid_Directory $destinationDirectory

	Write-Verbose "Utility_CopyFiles: sourceFilePathPattern = $sourceFilePathPattern"
	Write-Verbose "Utility_CopyFiles: destinationDirectory = $destinationDirectory"
	Copy-Item $sourceFilePathPattern $destinationDirectory -Force
}

function Utility_CreateConfuserExProjectFileFromTemplateFile
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $projectAssemblyFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $confuserExProjectTemplateFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $confuserExProjectFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $obfuscatedAssemblyDirectory
	)

	Utility_AssertValid_FilePath $projectAssemblyFilePath
	Utility_AssertValid_FilePath $confuserExProjectTemplateFilePath

	# read ConfuserEx template file
	[xml] $fileContents = Get-Content $confuserExProjectTemplateFilePath

	<#
		Note: the following lines must call 'ToString()' otherwise they generates the error
		"...only strings can be used as values to set XmlNode properties".  There appears
		to be bug in PowerShell (see http://stackoverflow.com/questions/10355578/why-is-powershell-telling-me-a-string-is-not-a-string-and-only-when-calling-str)
		and the work-around solution I found is to call 'ToString()'.
	#>
	$inputDirectory = Split-Path -Path $projectAssemblyFilePath -Parent
	$inputFileName = Split-Path -Path $projectAssemblyFilePath -Leaf
	$fileContents.project.outputDir = $obfuscatedAssemblyDirectory.ToString()
	$fileContents.project.baseDir = $inputDirectory.ToString()
	$fileContents.project.module.path = $inputFileName.ToString()
	
	# save ConfuserEx project file
	$fileContents.Save( $confuserExProjectFilePath )
	Utility_AssertValid_FilePath $confuserExProjectFilePath
}

function Utility_GACAssembly
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $projectAssemblyFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $solutionPlatform,

		[parameter (Mandatory=$true)] 
		[boolean] $installAssemblyInGAC

	)

	$gacFilePath = _getGACProgramFilePath $solutionPlatform

	if( $true -eq $installAssemblyInGAC ) {
		Utility_AssertValid_FilePath $projectAssemblyFilePath
		& $gacFilePath "-if" $projectAssemblyFilePath
	}
	else {
		& $gacFilePath "-u" $projectAssemblyFilePath 
	}
}

function Utility_ObfuscateProjectAssembly
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $confuserExFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $confuserExProjectFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $confuserExAssemblyFilePath
	)

	Utility_AssertValid_FilePath $confuserExFilePath
	Utility_AssertValid_FilePath $confuserExProjectFilePath

	if( Test-Path -Path $confuserExAssemblyFilePath ) {
		Remove-Item -Path $confuserExAssemblyFilePath
	}

	& $confuserExFilePath -nopause $confuserExProjectFilePath

	Utility_AssertValid_FilePath $confuserExAssemblyFilePath
}

function Utility_SetAssemblyStrongNameVerificationState
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $projectAssemblyFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $solutionPlatform,

		[parameter (Mandatory=$true)] 
		[boolean] $disableStrongNameVerification

	)
	
	Utility_AssertValid_FilePath $projectAssemblyFilePath
	$strongNamefilePath = _getSNProgramFilePath $solutionPlatform

	if( $true -eq $disableStrongNameVerification ) {
		# register for verification skipping
		& $strongNamefilePath "-Vr" $projectAssemblyFilePath
		Write-Verbose "Utility_SetAssemblyStrongNameVerificationState: $strongNamefilePath -Vr $projectAssemblyFilePath"
	}
	else {
		# un-register for verification skipping
		& $strongNamefilePath "-Vu" $projectAssemblyFilePath 
		Write-Verbose "Utility_SetAssemblyStrongNameVerificationState: $strongNamefilePath -Vu $projectAssemblyFilePath"
	}
}

function Utility_SignAssembly
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $projectAssemblyFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateNotNullOrEmpty()]
		[string] $strongNameKeyFilePath,

		[parameter (Mandatory=$true)] 
		[ValidateSet( "AnyCPU", "Any CPU", "x86", "x64", "Win32" )]
		[string] $solutionPlatform
	)

	Utility_AssertValid_FilePath $projectAssemblyFilePath
	Utility_AssertValid_FilePath $strongNameKeyFilePath
	
	$filePath = _getSNProgramFilePath $solutionPlatform
	& $filePath "-R" $projectAssemblyFilePath $strongNameKeyFilePath 
}

<#
	================================================================================================
	================================================================================================
	local variables
	================================================================================================
	================================================================================================
#>
[string] $_windowsSdkDirectory = "C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6.1 Tools\"

<#
	================================================================================================
	================================================================================================
	local functions
	================================================================================================
	================================================================================================
#>

function _getGACProgramFilePath
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateSet( "AnyCPU", "Any CPU", "x86", "x64", "Win32" )]
		[string] $solutionPlatform
	)
	
	$filePathX86 = Join-Path -Path $_windowsSdkDirectory -ChildPath "gacutil.exe"
	$filePathX64 = Join-Path -Path $_windowsSdkDirectory -ChildPath "x64\gacutil.exe"

	[string] $filePath
	switch( $solutionPlatform ) 
	{
		"AnyCPU" { $filePath = $filePathX64 }
		"Any CPU" { $filePath = $filePathX64 }
		"x64" {  $filePath = $filePathX64 }
		default { $filePath = $filePathX86 }
	}
	
	Utility_AssertValid_FilePath $filePath
	Write-Verbose "GAC program file path: $filePath" 
	$filePath
}

function _getSNProgramFilePath
{
	[CmdletBinding()]
	param(
		[parameter (Mandatory=$true)] 
		[ValidateSet( "AnyCPU", "Any CPU", "x86", "x64", "Win32" )]
		[string] $solutionPlatform
	)
	$filePathX86 = Join-Path -Path $_windowsSdkDirectory -ChildPath "sn.exe"
	$filePathX64 = Join-Path -Path $_windowsSdkDirectory -ChildPath "x64\sn.exe"

	[string] $filePath
	switch( $solutionPlatform ) 
	{
		"AnyCPU" { $filePath = $filePathX64 }
		"Any CPU" { $filePath = $filePathX64 }
		"x64" {  $filePath = $filePathX64 }
		default { $filePath = $filePathX86 }
	}
	Utility_AssertValid_FilePath $filePath
	Write-Verbose "strong name program file path: $filePath" 
	$filePath
}


