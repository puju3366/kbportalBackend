$(function(){
  $('body,html').hungryscroller({
    // slowSpeed: 25000,
    // medSpeed: 12000,
    // fastSpeed: 8000
  });
});